
<div class="container margin-top">

<div class="row">
        <div class="col-12 search__container p-5">
            <p class="search__title">
                Go ahead, and search images
            </p>
            <input id ="inside-search" class="search__input" type="text" placeholder="Search">
            
        </div>
    </div>

    <hgroup class="mb20">
		<h1>Search Results</h1>
		<h2 class="lead"><strong id="result-count" class="text-danger result">0</strong> results were found for the search for <strong class="text-danger">Lorem</strong></h2>								
	</hgroup>


    <section class="col-xs-12 col-sm-6 col-md-12 col-12">
        <div id="search-add"></div>
		<div class="text-center mt-4">
            <input type="hidden" id="count" value="0">
            <button class="btn btn-danger" onclick="searchCall('')">Load More</button>
        </div>		
  
    <!-- <section class="col-12 col-md-12">
		<article class="search-result row">
			<div class="col-xs-12 col-sm-12 col-md-3">
				<a href="#" title="Lorem ipsum" class="thumbnail"><img src="http://lorempixel.com/250/140/people" alt="Lorem ipsum" /></a>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-2">
				<ul class="meta-search">
					<li><i class="glyphicon glyphicon-calendar"></i> <span>02/15/2014</span></li>
					<li><i class="glyphicon glyphicon-time"></i> <span>4:28 pm</span></li>
					<li><i class="glyphicon glyphicon-tags"></i> <span>People</span></li>
				</ul>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-7 excerpet">
				<h3><a href="#" title="">Voluptatem, exercitationem, suscipit, distinctio</a></h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatem, exercitationem, suscipit, distinctio, qui sapiente aspernatur molestiae non corporis magni sit sequi iusto debitis delectus doloremque.</p>						
			</div>
			<span class="clearfix borda"></span>
		</article>		

	</section> -->
</div>