<script src="<?php echo URL_BASE .'assets/library/jquery/jquery-3.4.1.min.js';?>"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="<?php echo URL_BASE .'assets/library/bootstrap/js/bootstrap.min.js';?>"></script>
<script src="<?php echo URL_BASE .'assets/library/slick/slick/slick.min.js';?>"></script>
<script src="<?php echo URL_BASE .'assets/library/fontawesome/js/fontawesome.min.js';?>"></script>
<link rel="stylesheet" href="https://unpkg.com/swiper/css/swiper.css">
<link rel="stylesheet" href="https://unpkg.com/swiper/css/swiper.min.css">

<script src="https://unpkg.com/swiper/js/swiper.js"></script>
<script src="https://unpkg.com/swiper/js/swiper.min.js"></script>

<!-- <script src="./assets/library/scheletrone/jquery.scheletrone.js"></script> -->
<!-- SubViews -->
<script src="<?php echo URL_BASE .'views/sub-views/navigation.js';?>"></script>
<script src="<?php echo URL_BASE .'views/landing/landing.js';?>"></script>
<script src="<?php echo URL_BASE .'views/contact/contact.js';?>"></script>
<script src="<?php echo URL_BASE .'views/search-results/search-results.js';?>"></script>
<script src="<?php echo URL_BASE .'views/categories-images/categories-images.js';?>"></script>
<script src="<?php echo URL_BASE .'views/image-share-download/image-share-download.js';?>"></script>

<!-- categories images js -->

<!-- Landing Screen -->
<!-- <script src="./views/categories-images/categories-images.js"></script> -->
</body>

</html>